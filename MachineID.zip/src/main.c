#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#define WINDOW_WIDTH 320
#define WINDOW_HEIGHT 240

// Функция для получения UUID
char* get_uuid() {
    FILE *fp;
    char buffer[256];
    char *uuid = NULL;

    fp = popen("dmidecode -t system | grep UUID | awk '{print $2}'", "r");
    if (fp == NULL) {
        g_printerr("Failed to run dmidecode\n");
        return NULL;
    }

    if (fgets(buffer, sizeof(buffer), fp) != NULL) {
        uuid = g_strdup(buffer);
        uuid[strcspn(uuid, "\n")] = 0; // Удаляем перевод строки
    }

    pclose(fp);
    return uuid;
}

// Callback для кнопки "Copy"
void on_copy_button_clicked(GtkButton *button, gpointer data) {
    const char *uuid = (const char *)data;

    if (uuid) {
        GtkClipboard *clipboard = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD);
        gtk_clipboard_set_text(clipboard, uuid, -1);
        g_print("UUID copied to clipboard: %s\n", uuid);
    }
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    // Создание основного окна
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Machine ID");
    gtk_window_set_default_size(GTK_WINDOW(window), WINDOW_WIDTH, WINDOW_HEIGHT);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    // Создание центрального контейнера
    GtkWidget *grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Заголовок "Machine ID"
    GtkWidget *label_title = gtk_label_new("Machine ID");
    PangoFontDescription *font_title = pango_font_description_from_string("Sans 36");
    gtk_widget_override_font(label_title, font_title);
    pango_font_description_free(font_title);
    gtk_grid_attach(GTK_GRID(grid), label_title, 0, 0, 1, 1);
    gtk_widget_set_margin_start(label_title, 10);
    gtk_widget_set_margin_top(label_title, 10);

    // Метка для UUID
    char *uuid = get_uuid();
    GtkWidget *label_uuid = gtk_label_new(uuid ? uuid : "UUID not found");
    PangoFontDescription *font_uuid = pango_font_description_from_string("PT Mono 18");
    gtk_widget_override_font(label_uuid, font_uuid);
    pango_font_description_free(font_uuid);
    gtk_label_set_xalign(GTK_LABEL(label_uuid), 0.0);
    gtk_label_set_line_wrap(GTK_LABEL(label_uuid), TRUE);
    gtk_label_set_line_wrap_mode(GTK_LABEL(label_uuid), PANGO_WRAP_WORD);
    gtk_grid_attach(GTK_GRID(grid), label_uuid, 0, 1, 1, 1);
    gtk_widget_set_margin_start(label_uuid, 10);
    gtk_widget_set_margin_top(label_uuid, 10);

    // Кнопка "Copy"
    GtkWidget *button_copy = gtk_button_new_with_label("Copy");
    gtk_grid_attach(GTK_GRID(grid), button_copy, 0, 2, 1, 1);
    gtk_widget_set_margin_start(button_copy, 242);
    gtk_widget_set_margin_top(button_copy, 10);

    // Обработка событий
    g_signal_connect(button_copy, "clicked", G_CALLBACK(on_copy_button_clicked), uuid);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Отображение всех виджетов
    gtk_widget_show_all(window);

    // Запуск GTK главного цикла
    gtk_main();

    // Освобождение ресурсов
    g_free(uuid);

    return 0;
}
