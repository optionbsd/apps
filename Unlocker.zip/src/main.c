#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#define PASSWORD_FILE "/etc/passwd.user"
#define BACKGROUND_IMAGE "../res/Background.jpg"

// Функция для загрузки пароля из файла
char *load_password_hash() {
    FILE *file = fopen(PASSWORD_FILE, "r");
    if (!file) {
        g_printerr("Не удалось открыть файл %s\n", PASSWORD_FILE);
        return NULL;
    }

    char *hash = NULL;
    size_t len = 0;
    if (getline(&hash, &len, file) == -1) {
        g_printerr("Ошибка чтения пароля из файла\n");
        free(hash);
        fclose(file);
        return NULL;
    }

    fclose(file);

    // Удаляем символ новой строки, если он есть
    hash[strcspn(hash, "\n")] = '\0';
    return hash;
}

// Функция для проверки пароля с использованием OpenSSL
gboolean verify_password(const char *input, const char *hash) {
    if (!input || !hash) {
        return FALSE;
    }

    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int length = 0;
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();

    if (mdctx == NULL) {
        return FALSE;
    }

    if (1 != EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL)) {
        EVP_MD_CTX_free(mdctx);
        return FALSE;
    }

    if (1 != EVP_DigestUpdate(mdctx, input, strlen(input))) {
        EVP_MD_CTX_free(mdctx);
        return FALSE;
    }

    if (1 != EVP_DigestFinal_ex(mdctx, digest, &length)) {
        EVP_MD_CTX_free(mdctx);
        return FALSE;
    }

    EVP_MD_CTX_free(mdctx);

    char hash_hex[length * 2 + 1];
    for (unsigned int i = 0; i < length; i++) {
        sprintf(&hash_hex[i * 2], "%02x", digest[i]);
    }

    hash_hex[length * 2] = '\0';

    return strcmp(hash, hash_hex) == 0;
}

// Callback для обработки нажатия Enter
void on_password_enter(GtkEntry *entry, gpointer user_data) {
    const char *input_password = gtk_entry_get_text(entry);
    char *password_hash = load_password_hash();

    if (verify_password(input_password, password_hash)) {
        g_print("Пароль верный. Разблокировка...\n");
        gtk_main_quit(); // Закрыть окно
    } else {
        g_printerr("Неверный пароль!\n");
        gtk_entry_set_text(entry, ""); // Очистить поле ввода
    }

    free(password_hash);
}

// Callback для фокуса
void on_entry_focus(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_set_opacity(widget, 1.0); // Убираем прозрачность при фокусе
}

// Callback для потери фокуса
void on_entry_focus_out(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_set_opacity(widget, 0.7); // Возвращаем прозрачность
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    // Создаем полноэкранное окно
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
    gtk_window_fullscreen(GTK_WINDOW(window));

    // Закрытие программы при нажатии на "закрыть"
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Создаем контейнер для фонового изображения
    GtkWidget *layout = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(window), layout);

    // Устанавливаем фоновое изображение
    GtkWidget *image = gtk_image_new_from_file(BACKGROUND_IMAGE);
    gtk_layout_put(GTK_LAYOUT(layout), image, 0, 0);

    // Создаем поле ввода
    GtkWidget *entry = gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entry), FALSE); // Скрываем вводимый текст
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "Введите пароль");

    // Стилизация поля ввода
    gtk_widget_set_size_request(entry, 300, 50);
    gtk_widget_set_opacity(entry, 0.7); // Полупрозрачное поле

    // Размещаем поле ввода по центру
    GtkAllocation allocation;
    gtk_widget_get_allocation(window, &allocation);
    gtk_layout_put(GTK_LAYOUT(layout), entry, (allocation.width - 300) / 2, (allocation.height - 50) / 2);

    // Связываем события
    g_signal_connect(entry, "activate", G_CALLBACK(on_password_enter), NULL);
    g_signal_connect(entry, "focus-in-event", G_CALLBACK(on_entry_focus), NULL);
    g_signal_connect(entry, "focus-out-event", G_CALLBACK(on_entry_focus_out), NULL);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}
